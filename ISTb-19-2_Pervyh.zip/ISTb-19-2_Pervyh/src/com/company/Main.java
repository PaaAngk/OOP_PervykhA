package com.company;
import java.util.Arrays;
import java.util.*;

public class Main {

    public static void main(String[] args) {
        System.out.println("Вывод первой программы: ");
        Programm1();
        System.out.println("Вывод второй программы: ");
        Programm2();
        System.out.println("Вывод третьей программы: ");
        Programm3();
    }

    static void Programm1() {
        int m = 30;
        int[] source = new int[m];
        int evens = 0, odds = 0;
        Random Rndm = new Random();

        System.out.println("Исходная матрица: ");
        for (int i = 0; i < m; i++) {
            int Rn = Rndm.nextInt(100);
            System.out.print(Rn + " ");
            source[i] = Rn * Rn;
            //System.out.print(source[i] + " ");

            if (source[i] % 2 == 0) {
                evens++;
            } else {
                odds++;
            }
        }
        System.out.println();
        int[] masEven = new int[evens];
        int[] masOdd = new int[odds];
        int index1 = 0, index2 = 0;

        for (int i = 0; i < m; i++) {
            if (source[i] % 2 == 0) {
                masEven[index1++] = source[i];
            } else {
                masOdd[index2++] = source[i];
            }
        }

        System.out.println("Четные: " + Arrays.toString(masEven));
        System.out.println("Нечетные: " + Arrays.toString(masOdd));
    }
    static void Programm2() {
        int[] arr = new int[255];
        Scanner sc = new Scanner(System.in);
        System.out.println("Введите строку:");
        String str = sc.nextLine();
        while (!str.matches("[A-Za-z0-9,. ]+")){
            System.out.println("Неправильный ввод, повторите ввод.(Буквы, цифры, запятая, точка и пробел.)");
            str = sc.nextLine();
        }
        String result = str.toUpperCase();
        for (int i = 0; i < result.length(); i++) {
            arr[result.charAt(i)]++;
        }

        for (int i = 65; i < 91; i++) {
            System.out.println((char) i + " встречается " + arr[i] + " раз(а)");
        }
        for (int i = 48; i < 58; i++) {
            System.out.println((char) i + " встречается " + arr[i] + " раз(а)");
        }
        System.out.println("Пробел встречается " + arr[32] + " раз(а)");
        System.out.println("Запятая встречается " + arr[44] + " раз(а)");
        System.out.println("Точка встречается " + arr[46] + " раз(а)");
    }
    static void Programm3() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Объявите длину множества чисел: ");
        int msize;
        do {
            while (!sc.hasNextInt()) {
                System.out.println("Это не число!");
                sc.next();
            }
            msize = sc.nextInt();
        } while ((msize % 1) != 0);
        sc.nextLine();
        int[] arr = new int[msize];

        System.out.println("Введите условие Ваше услови, > 0 || < 10: ");

        int n;
        boolean moreThan;

        String s = sc.nextLine();
        String[] s1 = s.split(" ");
        moreThan = s1[0].equals(">");
        n = Integer.parseInt(s1[1]);

        System.out.println("Введите элементы массива: ");
        for (int i = 0; i < msize; i++) {
            do {
                while (!sc.hasNextInt()) {
                    System.out.println("Это не число!");
                    sc.next();
                }
                arr[i] = sc.nextInt();
            } while ((arr[i] % 1) != 0);
        }

        System.out.println("Множество чисел удовлетворяющие условию: ");
        for (int i = 0; i < msize; i++) {
            if (moreThan && arr[i] > n)
                System.out.print(arr[i]+ " ");
            else if (!moreThan && arr[i] < n)
                System.out.print(arr[i] + " ");
        }
        System.out.println();
    }
}
